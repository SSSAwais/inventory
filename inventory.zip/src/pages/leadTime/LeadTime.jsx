import React from "react"

const LeadTime = () => {
  return (
    <>
      <h1>Lead Page</h1>
    </>
  )
}

export default LeadTime
